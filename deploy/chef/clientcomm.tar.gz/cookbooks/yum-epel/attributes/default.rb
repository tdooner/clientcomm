default['yum-epel']['repos'] = %w(
  epel
  epel-debuginfo
  epel-source
  epel-testing
  epel-testing-debuginfo
  epel-testing-source
)
